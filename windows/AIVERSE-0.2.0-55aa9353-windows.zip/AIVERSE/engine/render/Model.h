// Models: node hierarchy, meshes, PBR materials, textures, skins and animation clips.
//
// Sources: glTF 2.0 (.gltf / .glb), Wavefront OBJ (+ .mtl), FBX (.fbx), voxels (.vox, .vxl), PLY, STL,
// 3DS, Collada (.dae), classic RTS formats (.mdx / .mdl, .3do, .w3d), and procedural meshes built with
// MeshBuilder (the built-in shapes). Every source ends up in the same Model structure, so the
// renderer, the animation system and the game view treat them identically.
//
// Conventions: Y up, right-handed, metres = map cells. glTF assets face +Z; the game view rotates
// them to the engine's +X forward (see RtsView "forward").
#pragma once
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>
#include "../gfx/Gfx.h"
#include "Math3D.h"
#include "TextureCodec.h"
#include "graph/ShaderGraph.h"

namespace aiverse::render {

class MeshBuilder;
struct GeometryData;

enum class AlphaMode : uint8_t { Opaque, Mask, Blend };
enum class ShadingModel : uint8_t { Pbr, Unlit };
// Where the team (player) colour goes:
//   Tint        whole material multiplied by the team colour (procedural shapes, simple models)
//   Mask        team mask texture, red channel 1 = team colour
//   BaseAlpha   base colour texture alpha, 0 = team colour (Warcraft III style); the material stays opaque
//   VertexAlpha vertex colour alpha, 0 = team colour
enum class TeamMode : uint8_t { None, Tint, Mask, BaseAlpha, VertexAlpha };

struct Material {
    std::shared_ptr<const graph::Program> shaderGraph;
    int graphTextures[4] = {-1,-1,-1,-1};
    std::string name;
    ShadingModel shading = ShadingModel::Pbr;
    float4 baseColor{1, 1, 1, 1};          // linear
    float metallic = 0, roughness = 0.8f;
    float normalScale = 1, occlusionStrength = 1;
    float3 emissive{0, 0, 0};              // linear, multiplied by emissiveStrength
    float emissiveStrength = 1;
    AlphaMode alpha = AlphaMode::Opaque;
    float alphaCutoff = 0.5f;
    bool doubleSided = false;
    bool vertexColors = true;              // multiply by COLOR_0
    bool castShadow = true, receiveShadow = true;
    bool transparent = false;              // drawn like DrawFlags kDrawTransparent (sorted, no depth write, depth after)
    TeamMode team = TeamMode::None;
    float teamStrength = 1;
    // texture image indices into Model::images (-1 = none)
    int baseTex = -1, mrTex = -1, normalTex = -1, occlusionTex = -1, emissiveTex = -1, teamTex = -1;
    // KHR_texture_transform of the base colour texture, applied to every texture of the material
    float2 uvOffset{0, 0}, uvScale{1, 1};
    float uvRotation = 0;
    // unlit with a fixed directional shade in world space: colour * (shade.x + shade.y * saturate(dot(N, dir)))
    // (prop shaders of art pipelines that light every instance by its own world normals); w = 0: off
    float4 fixedLight{0, 0, 0, 0};          // xyz direction towards the light (normalized), w 1 = on
    float2 fixedShade{1, 0};                // ambient, diffuse
};

struct Image {
    std::string name;               // file name or "#index" for embedded images
    int width = 0, height = 0;
    std::vector<uint8_t> rgba;      // CPU copy, released after upload
    // KTX2 source: raw GPU blocks of every mip level (rgba then holds the CPU-decoded level 0
    // as a fallback). Shared so Image stays cheap to copy; null for PNG/JPEG/TGA.
    std::shared_ptr<CompressedImage> compressed;
    bool repeat = true, nearest = false;
    gfx::TextureHandle tex;
    bool borrowedTexture = false; // owner must outlive this image; never released here
    bool gpuCompressed = false;     // uploaded as GPU blocks (KTX2)
};

// 60 bytes, one interleaved stream for every model (unskinned meshes leave joints/weights zero).
struct ModelVertex {
    float3 pos;
    float3 nrm;
    float2 uv;
    float4 tangent{1, 0, 0, 1};     // xyz tangent, w handedness
    uint32_t color = 0xffffffffu;   // RGBA8, linear
    uint8_t joints[4] = {0, 0, 0, 0};   // indices into Primitive::jointPalette
    uint8_t weights[4] = {0, 0, 0, 0};  // normalized
};
static_assert(sizeof(ModelVertex) == 60, "ModelVertex layout is shared with the shaders");

constexpr int kMaxPaletteJoints = 80;  // joint matrices per draw (3 x vec4 each, fits a 4 KB uniform block)
constexpr int kMaxMorphTargets = 8;    // morph targets applied on the GPU per primitive

struct Primitive {
    uint32_t firstIndex = 0, indexCount = 0;
    int material = 0;
    std::vector<uint16_t> jointPalette;  // palette slot -> joint index of the node's skin (empty: not skinned)
    std::vector<int> variantMaterial;    // KHR_materials_variants: variant index -> material (-1 = default)
    float3 boundsMin, boundsMax;         // mesh space (bind pose)
    uint32_t firstVertex = 0, vertexCount = 0;  // vertices of this primitive (contiguous)
    int morphTargets = 0;                // 0..kMaxMorphTargets
    uint32_t morphTexel = 0;             // first texel of its deltas in Model::morphTex
    std::vector<float> morphDeltas;      // CPU: [target][vertex] position xyz, normal xyz (released after upload)
};

struct ModelLod { int mesh = -1; float maxPixels = 0; };

struct MeshDef {
    std::string name;
    std::vector<Primitive> primitives;
    std::vector<float> weights;          // default morph weights
    std::vector<ModelLod> lods;          // coarse alternatives, descending maximum projected diameter
    float3 boundsMin, boundsMax;
    bool deformable = false;
};

struct Node {
    std::string name;
    int parent = -1;
    std::vector<int> children;
    float3 t{0, 0, 0};
    quat r;
    float3 s{1, 1, 1};
    int mesh = -1, skin = -1;
    float weights[kMaxMorphTargets] = {}; // morph weights (from the node or its mesh)
};

struct Skin {
    std::string name;
    std::vector<int> joints;          // node indices
    std::vector<mat4> inverseBind;
};

struct AnimChannel {
    enum Path : uint8_t { Translation, Rotation, Scale, Weights };
    enum Interp : uint8_t { Step, Linear, CubicSpline };
    int node = -1;
    Path path = Translation;
    Interp interp = Linear;
    std::vector<float> times;
    std::vector<float> values;        // comps floats per key; cubic: in-tangent, value, out-tangent per key
    uint8_t comps = 3;                // 3 (T, S), 4 (R), morph target count (Weights)
};

struct AnimClip {
    std::string name;
    float duration = 0;
    std::vector<AnimChannel> channels;
};

struct Model {
    std::shared_ptr<GeometryData> geometry;
    std::string path;
    std::vector<Node> nodes;
    std::vector<int> order;            // node indices, parents before children (finalize())
    std::vector<mat4> bindWorld;       // node world matrices of the bind pose (finalize())
    std::vector<MeshDef> meshes;
    std::vector<Material> materials;   // never empty after loading (a default material is added)
    std::vector<Image> images;
    std::vector<Skin> skins;
    std::vector<AnimClip> clips;
    std::vector<std::string> variants; // KHR_materials_variants names
    std::vector<ModelVertex> vertices; // CPU copy, released after upload
    std::vector<uint32_t> indices;
    gfx::BufferHandle vb, ib;
    float3 boundsMin, boundsMax;       // model space, bind pose (all meshes under their nodes)
    gfx::TextureHandle morphTex;       // RGBA32F deltas of every morphing primitive (2 texels per vertex and target)
    int morphTexWidth = 0;
    // Clips baked into joint matrices (bakeAnimations, Animation.h): crowds skin from a texture and
    // draw instanced. Row 0 is the bind pose; each row holds 3 texels (matrix rows) per skin joint.
    struct Baked {
        gfx::TextureHandle tex;
        int skin = -1, joints = 0, rows = 0;
        float fps = 30;
        struct Clip { int firstRow = 0, frames = 1; };
        std::vector<Clip> clips;
    } baked;

    int findNode(const std::string& name) const;
    int findClip(const std::string& name) const;     // exact, then case-insensitive
    int findMaterial(const std::string& name) const;
    int findVariant(const std::string& name) const;
    bool skinned() const { return !skins.empty(); }
    // Children lists, evaluation order, primitive and model bounds. Loaders call it.
    void finalize();
};

using FileReader = std::function<bool(const std::string& path, std::string& out)>;

// Loads .gltf / .glb / .obj / .fbx by extension. Throws std::runtime_error with a readable message
// ("models/knight.glb: accessor 3 out of range"). Unsupported optional features are reported in
// `warnings` and skipped (morph targets, compressed meshes fall back to an error).
std::unique_ptr<Model> loadModel(const std::string& path, const FileReader& read, std::vector<std::string>* warnings = nullptr);
std::unique_ptr<Model> loadGltf(const std::string& path, const std::string& bytes, const FileReader& read, std::vector<std::string>* warnings);
std::unique_ptr<Model> loadObj(const std::string& path, const std::string& text, const FileReader& read, std::vector<std::string>* warnings);
// FBX (binary / ASCII) through ufbx; converted to Y up, right-handed, metres.
std::unique_ptr<Model> loadFbx(const std::string& path, const std::string& bytes, const FileReader& read, std::vector<std::string>* warnings);
// Voxels: MagicaVoxel .vox (scene graph -> nodes, palette colours as vertex colours) and
// Tiberian Sun / Red Alert 2 .vxl (+ .hva section transforms next to it, + palette).
std::unique_ptr<Model> loadVox(const std::string& path, const std::string& bytes, const FileReader& read, std::vector<std::string>* warnings);
std::unique_ptr<Model> loadVxl(const std::string& path, const std::string& bytes, const FileReader& read, std::vector<std::string>* warnings);
// Interchange: Stanford .ply (ASCII / binary), .stl (ASCII / binary), 3D Studio .3ds, Collada .dae.
std::unique_ptr<Model> loadPly(const std::string& path, const std::string& bytes, const FileReader& read, std::vector<std::string>* warnings);
std::unique_ptr<Model> loadStl(const std::string& path, const std::string& bytes, const FileReader& read, std::vector<std::string>* warnings);
std::unique_ptr<Model> load3ds(const std::string& path, const std::string& bytes, const FileReader& read, std::vector<std::string>* warnings);
std::unique_ptr<Model> loadDae(const std::string& path, const std::string& bytes, const FileReader& read, std::vector<std::string>* warnings);
// Classic RTS formats, read from the user's own copy of a game (never committed): Warcraft III
// .mdx / .mdl (+ .blp textures), Total Annihilation .3do, C&C Generals .w3d (+ .dds / .tga).
std::unique_ptr<Model> loadMdx(const std::string& path, const std::string& bytes, const FileReader& read, std::vector<std::string>* warnings);
std::unique_ptr<Model> loadMdl(const std::string& path, const std::string& bytes, const FileReader& read, std::vector<std::string>* warnings);
std::unique_ptr<Model> load3do(const std::string& path, const std::string& bytes, const FileReader& read, std::vector<std::string>* warnings);
std::unique_ptr<Model> loadW3d(const std::string& path, const std::string& bytes, const FileReader& read, std::vector<std::string>* warnings);
// Formats the runtime does not read (.blend, .lwo, .x, .ms3d, ...) are converted to glTF on the
// host (tools/models/modelconv, assimp); the converted file sits next to the source as
// "<file>.glb" and loadModel picks it up for the original path.
bool isNativeModelFormat(const std::string& path);

// Textures of classic formats (decodeImage detects them by magic): Blizzard BLP1 / BLP2 and DDS
// (DXT1/3/5, BC4/5, uncompressed). Return false when the bytes are not that format or broken.
bool decodeBlp(const std::string& bytes, Image& out);
bool decodeDds(const std::string& bytes, Image& out);

// PNG / JPEG / TGA from memory into RGBA8. Returns false on failure.
bool decodeImage(const std::string& bytes, Image& out);

// Builds a model from named procedural parts (one node per part). Colors of the builder are
// treated as sRGB and converted to linear vertex colors.
struct ModelPart { std::string name; const MeshBuilder* mesh; Material material; mat4 xf; };
std::unique_ptr<Model> modelFromParts(const std::string& name, const std::vector<ModelPart>& parts);

// Missing tangents for normal mapping (per-vertex, from UVs).
void generateTangents(std::vector<ModelVertex>& v, const std::vector<uint32_t>& idx, uint32_t first, uint32_t count);

// GPU resources. Textures get mipmaps. CPU copies are released unless keepCpu.
bool uploadModel(gfx::Device& dev, Model& m, bool keepCpu = false);
int addImage(gfx::Device& dev, Model& m, Image img);   // extra texture for material overrides; returns index
void releaseModel(gfx::Device& dev, Model& m);

} // namespace aiverse::render

# Shader Graph

Shader Graph edits bounded fragment and material vertex graphs in **Графика → Shader Graph**.
One graph produces GLSL ES 3.00 / desktop GLSL 330 and Metal MSL. No shader source
from project data is executed directly. Existing games and built-in shaders remain valid.

Agent workflow and three applied examples: [Shader Graph agent guide](shader-graph-agents.md).

Expanded catalog (103 operations), textures, parameters and vertex outputs:
[Node reference](shader-graph-nodes.md).

## Editing

Open a project, choose `material`, `postfx` or `particle`, add nodes and connect
an output pin to an input pin by clicking each. Drag headers to move nodes;
middle-drag pans the canvas. The properties panel also exposes connections and outputs.
Escape cancels a pending connection. Delete removes a node; dangling connections
are reported and must be repaired. Undo/redo includes values, connections and layout.
Invalid graphs remain editable but cannot be saved/applied. Save or discard edits
before loading another graph. Preview runs the actual renderer on the current GPU:
a lit sphere, a postprocessed sphere image, or a looping particle emitter.

Assets are stored in `<project>/shaders/<name>.json`. **Save and apply** embeds a
validated snapshot into the destination. Reapply after editing the asset:

- `material`: target is a library material name in `materials.json`; existing keys
  are merged. Assign it to objects through the Materials window / `material_apply`.
- `postfx`: adds the `shaderGraph` effect to game.json, at medium quality by default.
  MCP supports `scope: "map"`. One graph effect, applied at the end of the composite;
  texture nodes sample the scene input, while Input is the current composited colour.
- `particle`: target is an existing FX name, emitter is a zero-based index.
  Applies to billboards, mesh particles and sprite frame batches. Trails keep their
  existing shader. Emitter `minQuality` controls availability on weaker devices.

The embedded snapshots travel in ordinary content packs without runtime file watchers.
Reapplying uses existing material/FX/postfx operations and their refresh behaviour.
The graph window retains unsaved per-project drafts in memory, not across editor exits.

Example assets: `examples/shader_graph/{material,postfx,particle}_tint.json`.
Copy one into the project shaders folder and load it by name.

## Format and operations

```json
{
  "version": 1,
  "domain": "material",
  "nodes": [
    {"id": "surface", "op": "input", "position": [40, 60]},
    {"id": "tint", "op": "constant", "value": [0.2, 0.6, 1, 1], "position": [40, 180]},
    {"id": "result", "op": "multiply", "inputs": ["surface", "tint"], "position": [260, 90]}
  ],
  "outputs": {"color": "result"}
}
```

All ports are float4 RGBA vectors. Scalar constants splat to all channels; material
roughness/metallic use the red channel and emission uses RGB. There are no implicit
connections by numeric index: input entries reference stable node IDs. Material colours
are linear, particle colours follow the existing particle display-space path, postfx
colours follow the existing LDR composite. UV nodes produce `[u,v,0,1]`.

The [node reference](shader-graph-nodes.md) describes all 103 operations and their
input order, domain and stage constraints. `shader_graph_catalog` reports arity,
domains and vertex eligibility. All previous operations keep their meaning.
Material texture samples decode sRGB RGB using the built-in model conversion and preserve alpha.
`texture` reads the existing base texture or scene; `sampleTexture` adds a project image,
and `sampleTextureLod` samples an independent image in a material fragment or vertex stage.
Up to four independent images are bound. `parameter` uses a named default or graph.parameters override.
Material outputs: required color; optional roughness, metallic, emission, world-space normal,
local-space vertexOffset and vertexNormal after skin/morph. Fragment graphs run before alpha
testing and lighting; vertex displacement runs in colour, outline and shadow passes.
Postfx and particle domains expose color only. See the node reference for clocks, particle
age/lifetime/random, numerical guards, texture colour spaces and quality settings.

Limits: 128 nodes, eight texture sample nodes, 64-character IDs, 256 KiB assets,
finite constants within +/-1,000,000. Missing connections, cycles, duplicate IDs,
unknown operations and incompatible output domains are errors. Cycles are checked
using the existing library topological ordering implementation. No compute, custom source nodes or Shader Graph imports.

## MCP

- `shader_graph_catalog`: supported operations and arities.
- `shader_graph_list`, `shader_graph_get {name}`: assets.
- `shader_graph_validate {graph}`: validation, generated GLSL/MSL statements and cost counts.
- `shader_graph_set {name,graph}`: validated atomic save.
- `shader_graph_apply {name,target,emitter?,scope?}`: embed the saved snapshot.
- `shader_graph_preview {name}` or `{graph}`: open in the graphical editor.

GPU compilation uses the normal Device error path. Model and postfx variants are
cached by graph source/content and variant state; particle batches include graph
identity. Invalid GPU variants report errors; postfx/particles retain the built-in
fallback. Project authors should check the preview on each target backend.

## Verification

`aiverse_shader_graph_tests` covers graph validation, ordering and domain round trips.
With an editor listening on a separate port and the graph window visible, run
`python3 tests/shader_graph/editor_smoke.py --port PORT --screenshots /tmp/graph-shots`.
It checks GPU diagnostics after every node/domain combination, not only CPU generation.
`shader_graph_preview_status` reports readiness and the current GPU diagnostic.

## Starter material library

Nine editable PBR presets and a safe project installer are documented in
[the material library](../examples/shader_graph/material_library/README.md).
The HDR test scene accepts `AIVERSE_MATERIAL_LIBRARY` to render their actual
material graphs as a gallery on GL and Metal.

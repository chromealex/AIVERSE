# Top-down heroes (twin-stick direct control)

One hero per player is steered directly (virtual joystick / WASD / gamepad) instead of with RTS orders, as in
Drone Fall and other mobile top-down shooters. Simulation: `modules/rts/RtsTopDown.{h,cpp}`; client model
(sticks, buttons, keys, camera): `modules/rts/view/TopDownControls.{h,cpp}`; client glue: `apps/client/ClientTopDown.cpp`.
Sample: `templates/topdown_arena` ("Scrapyard Arena").

## How it works

- **Heroes.** rules `topDown.heroes` lists unit types; the first own unit of such a type (placed by the map or the
  faction start, or trained later) becomes the player's hero. It carries `kUnitPossessed`: RTS orders, the
  computer player's army code and automatic target acquisition ignore it. `respawn` (seconds) brings a dead hero
  back where it first stood.
- **Input = commands.** One wire format for every hero game, the battle server and the load test
  (`engine/net/HeroInput.h`): `kCmdTopDown` = `net::kCmdHeroInput` (0xF100) and `kCmdTopDownAbility` =
  `net::kCmdHeroAbility` (0xF101). `kCmdTopDown` carries `topdown::pack(Input)`: move angle in binary turns (0 = +z, 16384 = +x),
  magnitude per mille, aim angle, aim / fire bits. The sim re-quantizes every command to `topDown.input`
  (`sectors`, `magnitudeSteps`, `deadzone`; Drone Fall: 45 sectors, step 1, dead zone 0.05), so all peers see the
  same integers. Input is **sticky**: clients send on change only. Under rollback netplay (`engine/net/Rollback.h`)
  the "no commands" prediction for a remote player therefore keeps his hero moving with its last input (dead
  reckoning); confirmations that differ roll back as usual. Lockstep latency is the session's input delay.
- **Movement.** Velocity eases toward the stick (`move.accel` up, `move.decel` when slowing / reversing; 0 =
  instant) at the unit's `Speed` stat (buffs, statuses apply; stun / root stop it). The body box (`move.radius`)
  stays on passable cells, cliffs need `canStep`, a blocked axis is dropped so heroes slide along walls; sub-steps
  of a quarter cell. `move.collideUnits` pushes the hero out of other ground (or air) bodies; structures block
  through the grid. Other units' local avoidance (ORCA) treats heroes as moving obstacles. Facing follows the aim,
  else (`aim.faceTarget`, off by default) the auto-fire target, else the movement, limited by `move.turnRate`
  (degrees / s). Drone Fall turns faceTarget on: the hero walks and shoots sideways with its strafe clips instead of
  turning to the target on every shot and back to the walk in between.
- **Targeting (Drone Fall rules, as data).** With an aim (aim stick, right stick, held mouse) the hero fires at the
  nearest valid target inside `aim.snapCone` (15 degrees) around the aim, also while moving. Without an aim,
  `autoFire` picks the nearest valid target in weapon range (`range` overrides) inside `cone` around the facing:
  `whileMoving: false` holds fire while the hero moves (Drone Fall's hero), `lineOfFire` rejects targets behind
  rock / structures, `retarget: "nearest"` re-evaluates every `interval` seconds and switches only to a target closer
  by more than `switchMargin`, `"keep"` stays on a valid target, `priority` types come first, `preferArmed` prefers
  things that shoot back. Valid = hostile, alive, visible to the owner, a layer the weapons hit, not invulnerable.
  The ordinary weapon system then fires (cooldowns, projectiles, damage, events).
- **Abilities.** `kCmdTopDownAbility` carries `topdown::abilityParam(Ability)`: ability index of the hero type, a
  phase (tap, press, release, cancel), optionally the button's stick direction (binary turns) and a distance (per
  mille of the range). Older clients send the bare index, which is a tap. Self / none abilities cast on the hero;
  point abilities go to the given point, else along the button's stick (at `distance` of the range), else along the
  aim (or facing) at full range, clamped to the range; unit abilities take the given target, else the nearest valid
  one inside the snap cone around the button's stick, else the current target, else the nearest valid one in range.
  Phases: **tap** casts; **press** remembers the stick and starts a **hold** ability (`abilities.hold`), which then
  recasts whenever it is ready until **release**; release casts an aimed (non-hold) ability along its stick;
  **cancel** casts nothing. A `castTime` runs as a windup in the sim (`kEvCastStart`); stun / silence / death cancel
  it, the stick keeps steering unless `abilities.rootWhileCasting`. A unit target that dies during the windup
  cancels the cast.
- **Free fire** (`aim.freeFire`). Aiming (or fire held) with nothing inside the snap cone fires the weapons along
  the aim anyway (Drone Fall): a weapon with a flight program flies it (the program stops on bodies / walls); any
  other shot travels to the first hostile body on the line or the first wall, within the weapon range. Off by
  default: the hero then only shoots at targets.
- **Squad** (`squad`). Own units of `squad.types` (up to `size` per hero, 0 = all) follow the hero: Drone Fall's
  Wander + unit group. Members carry `kUnitFollower` (RTS orders, the computer player's army code and selections
  leave them alone) and hold position (no chasing). Each member walks (pathfinding) to its slot on a ring of
  `radius` around the hero, member 0 behind it, turning with the hero's facing (`rotate`); a wall between hero and
  slot pulls the slot in front of the wall. Dead members leave the ring, which closes up. While the hero moves the
  members hold fire (`fireWhileMoving: false`, Drone Fall SupressFireOnMove); standing, they shoot with the
  ordinary auto-targeting. `repath` (seconds) is the slot refresh period. Respawned heroes keep their squad.
- **Escape** (`escape`, Drone Fall HeroEscape, PvE). The client starts a preview: for `duration` seconds the move
  stick walks a ghost point at the hero's speed, walls kept (a single-player match pauses meanwhile when `pause`;
  netplay keeps running), then sends the point as `kCmdTopDownAbility` with index 255. The sim checks it: hero
  alive, not cooling down, within speed * duration in a straight line and as walked (path length), passable; then
  the hero and its squad (in their ring slots) move there, `kEvGroupTeleport` fires per unit at the departure
  (value 2) and the arrival (value 0), and `cooldown` starts (per player, kept across hero replacement). State,
  HP and statuses stay; there is no invulnerability. Losing focus cancels the preview.
- **Bots.** `RtsAI` steers its hero with the same commands (`TopDown::botCommand`): walk (path around walls) to
  the nearest hostile, preferring armed ones, stop inside 85% of the weapon range so auto-fire works, give ground
  to armed foes closer than 35%.
- **Raid bots and other AI** never give a hero move / attack orders (it ignores them): `TopDown::steerCommand(goal,
  stand)` walks the hero there with the stick (straight when walkable, else the next path waypoint; stops inside
  `stand` so channels work) and kites: foes whose single hit is at least 5% of the hero's health (Drone Fall
  guardians' clubs), or, below 60% health, a swarm of 6+, push it away once they are within their weapon range
  + 2.5, with wall probes at 45 / 90 / 135 degrees; a hostile telegraph area (rules `encounters`) in windup or active
  that covers the hero outweighs everything: it steps out (away from a circle / cone origin, sideways off a line, to
  the nearer edge of a ring). Otherwise the hero stands and auto-fires. The raid bot
  (`RtsRaidBot.cpp`) uses it for objectives, kills, loot and extraction, keeps kiting before the raid starts and while
  it waits for a called point, and re-steers every 3 ticks. With rules `progression` it first walks over xp orbs
  within 14 units and, with a level banked and offers at circles, to the nearest summon circle
  (`Progression::botGoal`). Skirmish bots (`botCommand`) do the same only with `"bot": {"progression": true}`.
- **State / determinism.** `TopDownStore` world resource (rollback snapshots copy it), hashed, saved after the grid
  fields in `RtsSave`. Games without the block keep their checksums and save layout; so do top-down games that use
  none of squad / escape / hold / windups / free fire (`rules.extended`: only then is the extra pilot state — held
  button, windup, escape cooldown, squad — hashed and saved). Planets are not supported.
- **Outcome.** `RtsModule` freezes the match outcome at the end of the first tick with a result (`MatchOutcome`
  world resource, not hashed or saved): `result()` keeps returning it and `outcomeBlob()` (result, tick, per player
  slot / team / alive / units / structures / team score) never changes again. Hosted battle clients report that blob.

## Network (hosted battles, rollback)

- The battle server lets only the two hero commands through (`allowedCommands = {kCmdTopDown, kCmdTopDownAbility}`).
  `apps/battle/RtsBattle.h` runs a top-down project through the dedicated server, the secure transport and the
  simulated mobile network (`aiverse_battle load --project templates/topdown_arena`, test
  `hosted_rts_topdown_battle_agrees_on_the_outcome`).
- **Rollback corrections** of heroes and squad members are blended: the client installs
  `RollbackSession::setRollbackHook`, reads positions before and after the re-simulation and feeds the difference
  to the correction smoother (`modules/rts/view/TopDownPrediction.h`, `net::CorrectionSmoother`); large jumps
  (respawn, escape) snap.
- **Local visual prediction** (render only). Input reaches the sim after the input delay plus the interpolation lag;
  the client draws the local hero where the input already in flight takes it (sim position + integral of the
  stick's velocity over that lead), clamped by walls, eased. Nothing feeds the sim, so peers never diverge.
  game.json `topDown.prediction`: `false` or `{"enabled", "maxLead": 0.3, "maxOffset": 3, "easeHalfLifeMs": 35,
  "correctionHalfLifeMs": 50}`.

Weapons with ammo, free fire along the aim, pickups and money (GTA2 style): rules `arsenal`, docs/arsenal.md.
Vehicles the hero drives: rules `driving`, docs/driving.md.

## rules.json

```json
"topDown": {
  "heroes": ["drone"], "respawn": 8,
  "move": {"accel": 36, "decel": 54, "turnRate": 720, "collideUnits": true},
  "input": {"sectors": 45, "magnitudeSteps": 1, "deadzone": 0.05},
  "aim": {"snapCone": 15, "fires": true, "range": 0, "freeFire": true, "faceTarget": false},
  "abilities": {"hold": ["laser"], "rootWhileCasting": false},
  "squad": {"types": ["guard"], "size": 4, "radius": 2.5, "tolerance": 0.5, "rotate": true, "fireWhileMoving": false, "repath": 0.25},
  "escape": {"duration": 5, "cooldown": 30, "pause": true},
  "bot": {"progression": false, "orbRange": 14, "pathCheck": false,
          "kite": {"swarmHealth": 0.6, "swarmCount": 6, "hitShare": 0.05, "margin": 2.5},
          "pickups": [{"type": "medkit", "hurtBelow": 0.7, "range": 20}]},
  "autoFire": {"enabled": true, "whileMoving": false, "cone": 360, "range": 0, "lineOfFire": true,
               "retarget": "nearest", "interval": 0.2, "switchMargin": 0.5, "preferArmed": true,
               "priority": ["drone"], "movingSpeed": 0.1}
}
```

`"autoFire": false` switches auto-fire off (aim or the fire bit only).

Squad followers fire while they walk: an auto-targeting unit in range normally stops to shoot, a follower keeps
walking to its slot (with `squad.fireWhileMoving` it keeps shooting while the hero moves too).

### Bots (`bot`)

Tuning of the computer pilot (raid bots, skirmish bots with `bot.progression`, any `steerCommand` caller). Every key
is optional and the defaults are the values the pilot always used, so games without them play exactly as before.

| key | default | meaning |
|---|---|---|
| `progression` | false | skirmish bots walk to xp orbs / summon circles first (raid bots always do) |
| `orbRange` | 14 | xp orbs this close are collected before other goals; `"weapon"`: the hero's weapon range (+ range stat) |
| `kite.swarmHealth` | 0.6 | below this health share a crowd of armed foes is a threat (the hero backs off instead of standing in it) |
| `kite.swarmCount` | 6 | armed foes about to reach the hero that make a crowd |
| `kite.hitShare` | 0.05 | a foe whose single hit is this share of max health is a threat at any health |
| `kite.margin` | 2.5 | a foe inside its weapon range + margin is "about to reach" the hero |
| `pickups` | [] | `{"type", "hurtBelow" (share, 1 = always), "range"}`: units of that type (any owner, e.g. heal / magnet pickups a script spawns) the hero walks over first while its health is below `hurtBelow` |
| `pathCheck` | false | walk straight only when the whole body fits the line (else follow a path), and skip goals it cannot reach (pickups, orbs, raid goals: the nearest reachable of up to 4 is taken; none: the next kind of goal) instead of walking into a wall |

The map can change these per map (map `rules`, docs/game-format.md § Per-map rules overrides).

## game.json (client)

```json
"topDown": {
  "touchControls": "auto",            // auto: on touch devices; always; never
  "mouseAim": "hold",                 // hold: aim at the cursor while LMB is held (Drone Fall); always; off
  "joystick": {"mode": "floating", "radius": 64, "deadzone": 0.12, "area": [0, 0.3, 0.5, 1], "center": [0.14, 0.78]},
  "aimStick": {"enabled": true, "mode": "floating", "radius": 56, "deadzone": 0.2, "area": [0.5, 0.3, 1, 1]},
  "buttons": [{"ability": "missile", "mode": "aim", "dragRadius": 90, "key": "Q", "gamepad": 5, "anchor": [1, 1], "offset": [-70, -170], "radius": 32},
              {"ability": "laser", "mode": "hold", "key": "E", "anchor": [1, 1], "offset": [-150, -90], "radius": 28},
              {"ability": "escape", "key": "R", "anchor": [1, 1], "offset": [-60, -60], "radius": 30}],
  "prediction": {"enabled": true, "maxLead": 0.3},
  "gamepad": {"deadzone": 0.15},
  "aimAssist": {"touch": true, "pad": false, "mouse": false, "cone": 30, "range": 0, "stickiness": 1.4,
                "tapFire": true, "tapTime": 0.25, "tapFireTime": 0.4},
  "camera": {"pitch": 59, "yaw": 0, "distance": 22, "minDistance": 14, "maxDistance": 34, "smoothing": 6,
             "lookAhead": 2.5, "aimLookAhead": 1.5, "lookAheadSmoothing": 3, "lockOffsetIfNoInput": true,
             "velocityLookAhead": 0.45, "maxLookAhead": 5,
             "speedZoom": {"from": 2, "to": 9, "distance": 30, "smoothing": 1.2},
             "bounds": true, "margin": 4}
}
```

**Aim assist** (`aimAssist`, absent = off; `true` = touch + pad). Client side only: the aim of an assisted source
(touch aim stick, pad stick, mouse) bends to the target least off it inside `cone` degrees (nearer ones win ties; the
locked target stays inside `cone * stickiness`), and the sim receives an ordinary aim angle. Targets are
`TopDown::aimCandidates` — the manual-aim rules of the sim (hostile, visible, hittable layer, line of fire) within
`range` (0: rules `aim.range`, else the weapon range). `tapFire`: a touch on the aim stick shorter than `tapTime` that
barely moves it shoots at the nearest target for `tapFireTime` seconds. The locked target gets a marker
(`TopDownControls::drawLock`). Tests: `topdown_aim_assist_bends_touch_aim_and_taps_fire`,
`topdown_aim_candidates_follow_the_manual_aim_rules`.

**Speed camera** (GTA). The hero's speed is taken from its motion on screen, so it works on foot and at the wheel.
`speedZoom`: the distance goes from `distance` (at `from` world units / s and slower) to `speedZoom.distance` (at `to`
and faster) with its own `smoothing`; the player's wheel / pinch zoom stays underneath (min / max shift with it).
`velocityLookAhead` (seconds) moves the focus ahead of the motion by velocity * seconds; `maxLookAhead` caps the whole
look-ahead offset. At the wheel the stick look-ahead is off (the stick is pedals, not a direction). A jump of more
than 8 units between frames (respawn) is not speed. Test: `topdown_speed_camera_zooms_out_and_looks_ahead`.

**Lens** (`fov`, `projection`). `fov` is the vertical field of view in degrees (absent: the client camera's 43°).
Telephoto framings work: `"fov": 20` at `"distance": 320` shows about the ground a 43° lens shows at ~140. The
near / far clip planes follow the distance (near = max(0.5, distance / 50), far = max(1000, distance * 4)), the
shadow map is fitted to the ground the camera sees (so it shrinks with a narrow lens), and with a `fov` the distance
fog is scaled by tan(fov / 2) / tan(21.5°) — the fog a 43° lens framing the same ground would show (`"fogFollow":
false` keeps the authored density). `yaw` is any angle (180: the camera stands north of the hero and looks south;
sticks and keys stay screen-relative). `"projection": "ortho"` draws orthographically with the same framing
(`"perspective"` forces perspective; absent: whatever the game's camera has). Test:
`topdown_camera_fov_far_yaw_ortho_and_map_override`.

**Per-map camera.** A map's top-level `"camera"` block overrides `topDown.camera` key by key for that map
(`pitch`, `yaw`, `distance`, `minDistance`, `maxDistance`, `fov`, `projection`, `smoothing`, look-ahead, bounds...):

```json
"camera": {"distance": 116.6, "pitch": 57.8, "fov": 20}
```

 inside `area` (normalized screen rect) and follows a finger that
runs past 1.5 radii; `fixed` sits at `center`. Buttons: `tap` (default) casts on touch; `aim` sends press on touch,
then the drag away from the button aims it (direction, distance = drag / `dragRadius` of the range) and lifting the
finger casts (a drag shorter than a third of the button: along the aim); `hold` sends press / release (hold
abilities repeat). Keys behave the same (down / up; aimed at the cursor while LMB aims). `"ability": "escape"` is the
escape button: the preview ghost shows as a move marker and the camera follows it. Desktop: WASD / arrows move (camera-relative), held LMB aims at the
cursor, RMB / Space fire, button keys cast (aimed at the cursor while aiming). Gamepad: `TopDownFrameInput`
takes pad sticks / fire; the platform layer has no gamepad polling yet. The camera follows the interpolated hero
with exponential smoothing (aiverselib gameplay camera), a look-ahead along the stick / aim and map bounds; the
wheel / pinch zoom stays inside min / max. `AIVERSE_TOUCH_CONTROLS=1` draws the touch controls on desktop (screenshots).

## Tools

- MCP `play_command`: `{"command": "topdown", "player": 1, "move": [1, 0], "aim": [0, 1], "fire": true}`,
  `{"command": "topdown_ability", "ability": "missile", "at": [x, z]}`, `{"command": "topdown_ability", "ability":
  "missile", "phase": "release", "dir": [1, 0], "distance": 0.5}`, `{"command": "topdown_ability", "escape": true,
  "at": [x, z]}`. Lua `game.command(p, {type = "topdown",
  angle = 16384, magnitude = 1000, aim = true, aim_angle = 0})`.
- `rules_schema` / `rules_lint` read the loader, so the `topDown` keys are listed and typos reported.
- Tests: `aiverse_tests topdown_`.

## Not done (Drone Fall gaps)

Platform gamepad polling (pads feed `TopDownFrameInput` only), an aim-drag indicator drawn in the world (on screen a
knob off the button shows the drag), escape preview effects beyond the move marker (Drone Fall's grayscale camera / telegraph
circle: game view work), squad members walking as one rigid group (they path to their slots individually),
planets. Escape per mode / map: map `rules` (`{"topDown": {"escape": null}}` on a PvP map).

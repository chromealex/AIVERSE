// Lua tables for the client platform services, in the UI Lua state next to
// store.* / ads.*:
//   social.available() social.provider() social.user(fn(u)) social.unlock(id[, fn(ok, err)])
//   social.progress(id, cur, max) social.achievements(fn(list, err)) social.stat(id[, fn(v)])
//   social.setStat(id, v) social.addStat(id, d) social.friends(fn(list, err)) social.presence(key, value)
//   social.clearPresence() social.overlay(page) social.invite(connect[, friendId])
//   push.available() push.permission(fn(granted)) push.token(fn(t)) push.schedule{id, title, body, delay,
//   category, tag, data, repeat} push.cancel(id) push.cancelCategory(c) push.cancelTag(t) push.cancelAll() push.badge(n)
//   links.available() links.initial(fn(link)) links.parse(url) -> {scheme, host, path, query = {..}}
//   consent.available() consent.request(fn(r)[, debugEEA]) consent.options(fn(r)): r = {status, canRequestAds, personalized, optionsRequired}
//   plugins.available(name) plugins.call(name, method, args, fn(ok, data_or_error)): any plugin method (backend tokens,
//   SDK extras such as xsolla.token) for game scripts that need more than the services above
//   plugins.on(name, fn(event, data, name)) plugins.off(name[, fn]): events one plugin sends (plugins::emit), to UI Lua
// Events through game.on (ui/lib/meta.lua): "social" {event, data}, "push" {event, data}, "link" {url, source, deferred, data}.
extern "C" {
#include <lauxlib.h>
#include <lua.h>
}

#include <cstdio>
#include <memory>

#include "ClientServices.h"
#include "engine/platform/Plugins.h"
#include "engine/services/Consent.h"
#include "engine/services/Links.h"
#include "engine/services/Push.h"
#include "engine/services/Social.h"
#include "engine/ui/UiLua.h"

namespace aiverse::client {
namespace {

struct Ctx {
    std::shared_ptr<bool> alive;
    std::function<void(const char*, const Json&)> emit;
    lua_State* L = nullptr;
    int handlers = LUA_NOREF;   // registry: {[plugin name] = {fn, ...}} of plugins.on
};
Ctx& ctx(lua_State* L) { return *static_cast<Ctx*>(lua_touserdata(L, lua_upvalueindex(1))); }

struct Cb {
    std::shared_ptr<bool> alive;
    lua_State* L = nullptr;
    int ref = LUA_NOREF;
    void call(const Json& a, const Json* b = nullptr) {
        if (!*alive || ref == LUA_NOREF) return;
        lua_rawgeti(L, LUA_REGISTRYINDEX, ref);
        luaL_unref(L, LUA_REGISTRYINDEX, ref);
        ref = LUA_NOREF;
        ui::luaPushJson(L, a);
        if (b) ui::luaPushJson(L, *b);
        if (lua_pcall(L, b ? 2 : 1, 0, 0) != LUA_OK) {
            std::fprintf(stderr, "[lua] %s\n", lua_tostring(L, -1));
            lua_pop(L, 1);
        }
    }
};
std::shared_ptr<Cb> keep(lua_State* L, int idx) {
    auto c = std::make_shared<Cb>();
    c->alive = ctx(L).alive;
    c->L = L;
    if (lua_isfunction(L, idx)) { lua_pushvalue(L, idx); c->ref = luaL_ref(L, LUA_REGISTRYINDEX); }
    return c;
}
Json err(bool ok, const std::string& e) { return ok ? Json() : Json::string(e); }

// ---------------------------------------------------------------- social
int sAvailable(lua_State* L) { lua_pushboolean(L, social::available()); return 1; }
int sProvider(lua_State* L) { lua_pushstring(L, social::provider().c_str()); return 1; }
int sUser(lua_State* L) {
    auto cb = keep(L, 1);
    social::user([cb](const social::User& u) {
        Json j = Json::object();
        j.set("id", Json::string(u.id)); j.set("name", Json::string(u.name));
        j.set("language", Json::string(u.language)); j.set("country", Json::string(u.country));
        Json e = err(u.ok, u.error);
        cb->call(u.ok ? j : Json(), &e);
    });
    return 0;
}
int sUnlock(lua_State* L) {
    auto cb = keep(L, 2);
    social::unlock(luaL_checkstring(L, 1), [cb](bool ok, const std::string& e) { Json x = err(ok, e); cb->call(Json::fromBool(ok), &x); });
    return 0;
}
int sProgress(lua_State* L) { social::progress(luaL_checkstring(L, 1), int(luaL_checkinteger(L, 2)), int(luaL_checkinteger(L, 3))); return 0; }
int sAchievements(lua_State* L) {
    auto cb = keep(L, 1);
    social::achievements([cb](bool ok, const std::vector<social::Achievement>& list, const std::string& e) {
        Json a = Json::array();
        for (auto& x : list) {
            Json j = Json::object();
            j.set("id", Json::string(x.id)); j.set("name", Json::string(x.name)); j.set("description", Json::string(x.description));
            j.set("unlocked", Json::fromBool(x.unlocked)); j.set("unlockTime", Json::number(x.unlockTime));
            a.push(j);
        }
        Json ee = err(ok, e);
        cb->call(a, &ee);
    });
    return 0;
}
int sStat(lua_State* L) {
    auto cb = keep(L, 2);
    social::stat(luaL_checkstring(L, 1), [cb](bool ok, double v) { cb->call(ok ? Json::number(v, 6) : Json()); });
    return 0;
}
int sSetStat(lua_State* L) { social::setStat(luaL_checkstring(L, 1), luaL_checknumber(L, 2)); return 0; }
int sAddStat(lua_State* L) { social::addStat(luaL_checkstring(L, 1), luaL_checknumber(L, 2)); return 0; }
int sFriends(lua_State* L) {
    auto cb = keep(L, 1);
    social::friends([cb](bool ok, const std::vector<social::Friend>& list, const std::string& e) {
        Json a = Json::array();
        for (auto& f : list) {
            Json j = Json::object();
            j.set("id", Json::string(f.id)); j.set("name", Json::string(f.name)); j.set("state", Json::string(f.state));
            j.set("playing", Json::fromBool(f.playingThisGame)); j.set("status", Json::string(f.status));
            a.push(j);
        }
        Json ee = err(ok, e);
        cb->call(a, &ee);
    });
    return 0;
}
int sPresence(lua_State* L) { social::setPresence(luaL_checkstring(L, 1), luaL_optstring(L, 2, "")); return 0; }
int sClearPresence(lua_State*) { social::clearPresence(); return 0; }
int sOverlay(lua_State* L) { social::overlay(luaL_optstring(L, 1, "friends")); return 0; }
int sInvite(lua_State* L) { social::invite(luaL_optstring(L, 1, ""), luaL_optstring(L, 2, "")); return 0; }

// ---------------------------------------------------------------- push
int pAvailable(lua_State* L) { lua_pushboolean(L, push::available()); return 1; }
int pPermission(lua_State* L) { auto cb = keep(L, 1); push::requestPermission([cb](bool g) { cb->call(Json::fromBool(g)); }); return 0; }
int pToken(lua_State* L) { auto cb = keep(L, 1); push::token([cb](const std::string& t) { cb->call(Json::string(t)); }); return 0; }
int pSchedule(lua_State* L) {
    Json o = ui::luaToJson(L, 1);
    push::Local n;
    n.id = o.getStr("id"); n.title = o.getStr("title"); n.body = o.getStr("body");
    n.delay = o["delay"].toDouble(0); n.category = o.getStr("category"); n.tag = o.getStr("tag");
    n.repeat = o.getInt("repeat", 0);
    if (o.has("data")) n.data = o["data"].dump(-1);
    auto cb = keep(L, 2);
    push::schedule(n, [cb](bool ok, const std::string& e) { Json x = err(ok, e); cb->call(Json::fromBool(ok), &x); });
    return 0;
}
int pCancel(lua_State* L) { push::cancel(luaL_checkstring(L, 1)); return 0; }
int pCancelCategory(lua_State* L) { push::cancelCategory(luaL_checkstring(L, 1)); return 0; }
int pCancelTag(lua_State* L) { push::cancelTag(luaL_checkstring(L, 1)); return 0; }
int pCancelAll(lua_State*) { push::cancelAll(); return 0; }
int pBadge(lua_State* L) { push::setBadge(int(luaL_checkinteger(L, 1))); return 0; }

// ---------------------------------------------------------------- links
Json linkJson(const links::Link& l) {
    Json j = Json::object();
    j.set("url", Json::string(l.url)); j.set("source", Json::string(l.source)); j.set("deferred", Json::fromBool(l.deferred));
    try { j.set("data", Json::parse(l.dataJson)); } catch (...) { j.set("data", Json::object()); }
    return j;
}
int lAvailable(lua_State* L) { lua_pushboolean(L, links::available()); return 1; }
int lInitial(lua_State* L) { auto cb = keep(L, 1); links::initial([cb](const links::Link& l) { cb->call(linkJson(l)); }); return 0; }
int lParse(lua_State* L) {
    links::Parsed p = links::parse(luaL_checkstring(L, 1));
    Json j = Json::object(), q = Json::object();
    j.set("scheme", Json::string(p.scheme)); j.set("host", Json::string(p.host)); j.set("path", Json::string(p.path));
    for (auto& [k, v] : p.query) q.set(k, Json::string(v));
    j.set("query", q);
    ui::luaPushJson(L, j);
    return 1;
}

// ---------------------------------------------------------------- consent, plugins
Json consentJson(const consent::Result& r) {
    Json j = Json::object();
    j.set("status", Json::string(consent::name(r.status))); j.set("canRequestAds", Json::fromBool(r.canRequestAds));
    j.set("personalized", Json::fromBool(r.personalized)); j.set("optionsRequired", Json::fromBool(r.privacyOptionsRequired));
    if (!r.error.empty()) j.set("error", Json::string(r.error));
    return j;
}
int cAvailable(lua_State* L) { lua_pushboolean(L, consent::available()); return 1; }
int cRequest(lua_State* L) {
    auto cb = keep(L, 1);
    consent::request([cb](const consent::Result& r) { cb->call(consentJson(r)); }, lua_toboolean(L, 2));
    return 0;
}
int cOptions(lua_State* L) { auto cb = keep(L, 1); consent::showOptions([cb](const consent::Result& r) { cb->call(consentJson(r)); }); return 0; }
int gAvailable(lua_State* L) { lua_pushboolean(L, plugins::available(luaL_checkstring(L, 1))); return 1; }
int gCall(lua_State* L) {
    std::string name = luaL_checkstring(L, 1), method = luaL_checkstring(L, 2);
    std::string args = lua_isnoneornil(L, 3) ? "{}" : ui::luaToJson(L, 3).dump(-1);
    auto cb = keep(L, 4);
    plugins::call(name, method, args, [cb](const plugins::Result& r) {
        Json data;
        if (r.ok) { try { data = Json::parse(r.data); } catch (...) { data = Json::string(r.data); } }
        else data = Json::string(r.error);
        cb->call(Json::fromBool(r.ok), &data);
    });
    return 0;
}

// plugins.on(name, fn): fn(event, data, name) for every event that plugin emits (plugins::emit), in order of
// registration; plugins.off(name[, fn]) removes fn (or every handler of that plugin).
void pushHandlers(lua_State* L, Ctx& c) {
    if (c.handlers == LUA_NOREF) { lua_newtable(L); lua_pushvalue(L, -1); c.handlers = luaL_ref(L, LUA_REGISTRYINDEX); }
    else lua_rawgeti(L, LUA_REGISTRYINDEX, c.handlers);
}
int gOn(lua_State* L) {
    const char* name = luaL_checkstring(L, 1);
    luaL_checktype(L, 2, LUA_TFUNCTION);
    pushHandlers(L, ctx(L));
    if (lua_getfield(L, -1, name) != LUA_TTABLE) {
        lua_pop(L, 1);
        lua_newtable(L);
        lua_pushvalue(L, -1);
        lua_setfield(L, -3, name);
    }
    lua_pushvalue(L, 2);
    lua_rawseti(L, -2, lua_Integer(lua_rawlen(L, -2) + 1));
    lua_pop(L, 2);
    return 0;
}
int gOff(lua_State* L) {
    const char* name = luaL_checkstring(L, 1);
    const bool all = lua_isnoneornil(L, 2);
    pushHandlers(L, ctx(L));
    const int handlers = lua_gettop(L);
    if (all) {
        lua_pushnil(L);
        lua_setfield(L, handlers, name);
    } else if (lua_getfield(L, handlers, name) == LUA_TTABLE) {
        const int list = lua_gettop(L);
        lua_newtable(L);   // the list without fn
        const int kept = lua_gettop(L);
        lua_Integer n = 0;
        const lua_Integer len = lua_Integer(lua_rawlen(L, list));
        for (lua_Integer i = 1; i <= len; ++i) {
            lua_rawgeti(L, list, i);
            if (lua_rawequal(L, -1, 2)) lua_pop(L, 1);
            else lua_rawseti(L, kept, ++n);
        }
        lua_setfield(L, handlers, name);
    }
    lua_settop(L, handlers - 1);
    return 0;
}
void callHandlers(Ctx& c, const std::string& plugin, const std::string& ev, const Json& data) {
    lua_State* L = c.L;
    if (!L || c.handlers == LUA_NOREF) return;
    lua_rawgeti(L, LUA_REGISTRYINDEX, c.handlers);
    if (lua_getfield(L, -1, plugin.c_str()) != LUA_TTABLE) { lua_pop(L, 2); return; }
    const lua_Integer n = lua_Integer(lua_rawlen(L, -1));
    for (lua_Integer i = 1; i <= n; ++i) {   // a handler may call plugins.off: the list in hand stays as it was
        lua_rawgeti(L, -1, i);
        if (!lua_isfunction(L, -1)) { lua_pop(L, 1); continue; }
        lua_pushstring(L, ev.c_str());
        ui::luaPushJson(L, data);
        lua_pushstring(L, plugin.c_str());
        if (lua_pcall(L, 3, 0, 0) != LUA_OK) {
            std::fprintf(stderr, "[lua] plugins.on(%s): %s\n", plugin.c_str(), lua_tostring(L, -1));
            lua_pop(L, 1);
        }
        if (!*c.alive) return;   // the state went away inside the handler
    }
    lua_pop(L, 2);
}

void table(lua_State* L, Ctx* c, const char* name, std::initializer_list<luaL_Reg> fns) {
    lua_newtable(L);
    for (auto& f : fns) {
        lua_pushlightuserdata(L, c);
        lua_pushcclosure(L, f.func, 1);
        lua_setfield(L, -2, f.name);
    }
    lua_setglobal(L, name);
}

} // namespace

struct ClientServices::Impl {
    Ctx ctx;
    int socialId = 0, pushId = 0, linkId = 0, pluginId = 0;
};

ClientServices::ClientServices() = default;
ClientServices::~ClientServices() { detach(); }

void ClientServices::attach(lua_State* L, std::shared_ptr<bool> alive, std::function<void(const char*, const Json&)> emit) {
    detach();
    impl_ = std::make_unique<Impl>();
    impl_->ctx.alive = std::move(alive);
    impl_->ctx.emit = std::move(emit);
    Ctx* c = &impl_->ctx;
    table(L, c, "social", {{"available", sAvailable}, {"provider", sProvider}, {"user", sUser}, {"unlock", sUnlock}, {"progress", sProgress},
                           {"achievements", sAchievements}, {"stat", sStat}, {"setStat", sSetStat}, {"addStat", sAddStat},
                           {"friends", sFriends}, {"presence", sPresence}, {"clearPresence", sClearPresence}, {"overlay", sOverlay},
                           {"invite", sInvite}});
    table(L, c, "push", {{"available", pAvailable}, {"permission", pPermission}, {"token", pToken}, {"schedule", pSchedule},
                         {"cancel", pCancel}, {"cancelCategory", pCancelCategory}, {"cancelTag", pCancelTag}, {"cancelAll", pCancelAll},
                         {"badge", pBadge}});
    table(L, c, "links", {{"available", lAvailable}, {"initial", lInitial}, {"parse", lParse}});
    table(L, c, "consent", {{"available", cAvailable}, {"request", cRequest}, {"options", cOptions}});
    c->L = L;
    table(L, c, "plugins", {{"available", gAvailable}, {"call", gCall}, {"on", gOn}, {"off", gOff}});
    auto relay = [c](const char* kind) {
        return [c, kind](const std::string& ev, const std::string& data) {
            if (!*c->alive || !c->emit) return;
            Json j = Json::object();
            j.set("event", Json::string(ev));
            try { j.set("data", Json::parse(data)); } catch (...) { j.set("data", Json()); }
            c->emit(kind, j);
        };
    };
    impl_->socialId = social::onEvent(relay("social"));
    impl_->pushId = push::onEvent(relay("push"));
    // Events of every plugin (a game's native plugin talks back with plugins::emit): game.on('plugin', fn{plugin,event,data})
    impl_->pluginId = plugins::addAnyListener([c](const std::string& plugin, const std::string& ev, const std::string& data) {
        if (!*c->alive || !c->emit) return;
        Json j = Json::object();
        j.set("plugin", Json::string(plugin));
        j.set("event", Json::string(ev));
        try { j.set("data", Json::parse(data)); } catch (...) { j.set("data", Json()); }
        c->emit("plugin", j);
        if (*c->alive) callHandlers(*c, plugin, ev, j["data"]);   // plugins.on(plugin, fn)
    });
    impl_->linkId = links::onLink([c](const links::Link& l) { if (*c->alive && c->emit) c->emit("link", linkJson(l)); });
}

void ClientServices::detach() {
    if (!impl_) return;
    social::removeListener(impl_->socialId);
    push::removeListener(impl_->pushId);
    links::removeListener(impl_->linkId);
    plugins::removeListener(impl_->pluginId);
    impl_.reset();
}

} // namespace aiverse::client
